# Project Rules: GoodbyeDPI Pro MAX

## Mandatory Memory Protocol (claude-mem)
On every query and prompt:
- Always consult claude-mem cross-session memory for context regarding GoodbyeDPI Pro MAX architecture, profiles, theme palette specifications, failover algorithms, and .NET Framework 4.8 / C# 5 compiler constraints.
- Retain knowledge of all decisions and optimizations made in previous sessions.
